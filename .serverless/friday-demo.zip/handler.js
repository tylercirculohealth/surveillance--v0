const { extractListingsFromHTML } = require("./helpers");
const { sendSnsMsg } = require("./sns_publishtopic");
const { differenceWith, isEqual } = require("lodash");
// const { sqsAlert } = require("./sqshelper");
const AWS = require("aws-sdk");
// const axios = require('axios');
const dynamo = new AWS.DynamoDB.DocumentClient();
const request = require("axios");

// Todo: change to async

module.exports.hello = (event, context, callback) => {
  let todaysData, previousData;

  request("http://18.222.127.110/")
    .then(({ data }) => {
      previousData = extractListingsFromHTML(data);

      return dynamo
        .scan({
          TableName: "scannedData",
        })
        .promise();
    })
    .then((response) => {
      let yesterdaysData = response.Items[0] ? response.Items[0].dataDump : [];

      // Use lodash method to deeply compare the old response to the new in Dynamo

      todaysData = differenceWith(previousData, yesterdaysData, isEqual);

      const dataToDelete = response.Items[0]
        ? response.Items[0].id
        : null;

      // If the data is the same, delete old and input new

      if (dataToDelete) {
        return dynamo
          .delete({
            TableName: "scannedData",
            Key: {
              id: dataToDelete,
            },
          })
          .promise();
      } else return;
    })
    .then(() => {
      return dynamo
        .put({
          TableName: "scannedData",
          Item: {
            id: new Date().toString(),
            dataDump: previousData,
            // urID: //urlId
          },
        })
        .promise();
    })
    // Filter opposed to scan 
    // If retrieved data contains new html, send a msg to the slack channel and write a msg to SQS
    .then(() => {
      if (todaysData.length) {
        sendSnsMsg()
        // axios
        //   .post(
        //     "https://vl2gpt9uoh.execute-api.us-east-1.amazonaws.com/dev/notification",
        //     {
        //       url: "http://18.222.127.110/",
        //     }
        //   )
        //   .then(function (response) {
        //     console.log(response);
        //   })
        //   .catch(function (error) {
        //     console.log(error);
        //   });
      }
      callback(null, { dataDump: todaysData });
    })
    .catch(callback);
};
