var AWS = require("aws-sdk");
var sqs = require("sqs");
const SQS_QUEUE_URL = process.env.SQS_QUEUE_URL;

// Create an SQS service object
function sqsAlert() {
  var sqs = new AWS.SQS({ apiVersion: "2012-11-05" });

  var params = {
    DelaySeconds: 0,
    MessageAttributes: {
      Title: {
        DataType: "String",
        StringValue: "New Notification",
      },
    },
    MessageBody: "Surveilence has detected a change on http://18.222.127.110/",

    QueueUrl: "SQS_QUEUE_URL",
  };

  sqs.sendMessage(params, function (err, data) {
    if (err) {
      console.log("Error", err);
    } else {
      console.log("Success", data.MessageId);
    }
  });
}

module.exports = {
  sqsAlert,
};
